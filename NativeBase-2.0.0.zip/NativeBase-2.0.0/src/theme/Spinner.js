import { Platform } from 'react-native';
import _ from 'lodash';

import variable from './variables';

export default (variables = variable) => {
  const spinnerTheme = {
    height: 80,
  };


  return spinnerTheme;
};
